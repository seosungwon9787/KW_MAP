package com.example.kwabang;

import android.content.DialogInterface;
import android.content.Intent;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CollegeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college);

        Button collegeButton1 = (Button) findViewById(R.id.collegebtn1);
        collegeButton1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                AlertDialog.Builder builder = new AlertDialog.Builder(CollegeActivity.this);
                builder.setMessage("원하시는 작업을 선택해주세요");
                builder.setTitle("전자정보공과대학")
                        .setCancelable(false)
                        .setPositiveButton("단과대 정보 보기", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://kwabang.website/%ec%a0%84%ec%9e%90%ec%a0%95%eb%b3%b4%ea%b3%b5%ea%b3%bc%eb%8c%80%ed%95%99/"));
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("커뮤니티", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(getApplicationContext(), ElecActivity.class);
                                startActivity(intent);
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("전자정보공과대학");
                alert.show();
            }
        });

        Button collegeButton2 = (Button) findViewById(R.id.collegebtn2);
        collegeButton2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                AlertDialog.Builder builder = new AlertDialog.Builder(CollegeActivity.this);
                builder.setMessage("원하시는 작업을 선택해주세요");
                builder.setTitle("소프트웨어융합대학")
                        .setCancelable(false)
                        .setPositiveButton("단과대 정보 보기", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://kwabang.website/%ec%86%8c%ed%94%84%ed%8a%b8%ec%9b%a8%ec%96%b4%ec%9c%b5%ed%95%a9%eb%8c%80%ed%95%99/"));
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("커뮤니티", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(getApplicationContext(), SoftActivity.class);
                                startActivity(intent);
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("소프트웨어융합대학");
                alert.show();
            }
        });

        Button collegeButton3 = (Button) findViewById(R.id.collegebtn3);
        collegeButton3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                AlertDialog.Builder builder = new AlertDialog.Builder(CollegeActivity.this);
                builder.setMessage("원하시는 작업을 선택해주세요");
                builder.setTitle("공과대학")
                        .setCancelable(false)
                        .setPositiveButton("단과대 정보 보기", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://kwabang.website/%ea%b3%b5%ea%b3%bc%eb%8c%80%ed%95%99/"));
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("커뮤니티", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(getApplicationContext(), EnginActivity.class);
                                startActivity(intent);
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("공과대학");
                alert.show();
            }
        });

        Button collegeButton4 = (Button) findViewById(R.id.collegebtn4);
        collegeButton4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                AlertDialog.Builder builder = new AlertDialog.Builder(CollegeActivity.this);
                builder.setMessage("원하시는 작업을 선택해주세요");
                builder.setTitle("자연과학대학")
                        .setCancelable(false)
                        .setPositiveButton("단과대 정보 보기", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://kwabang.website/%ec%9e%90%ec%97%b0%ea%b3%bc%ed%95%99%eb%8c%80%ed%95%99/"));
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("커뮤니티", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(getApplicationContext(), NaturalActivity.class);
                                startActivity(intent);
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("자연과학대학");
                alert.show();
            }
        });

        Button collegeButton5 = (Button) findViewById(R.id.collegebtn5);
        collegeButton5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                AlertDialog.Builder builder = new AlertDialog.Builder(CollegeActivity.this);
                builder.setMessage("원하시는 작업을 선택해주세요");
                builder.setTitle("인문사회과학대학")
                        .setCancelable(false)
                        .setPositiveButton("단과대 정보 보기", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://kwabang.website/%ec%9d%b8%eb%ac%b8%ec%82%ac%ed%9a%8c%ea%b3%bc%ed%95%99%eb%8c%80%ed%95%99/"));
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("커뮤니티", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(getApplicationContext(), SocialActivity.class);
                                startActivity(intent);
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("인문사회과학대학");
                alert.show();
            }
        });

        Button collegeButton6 = (Button) findViewById(R.id.collegebtn6);
        collegeButton6.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                AlertDialog.Builder builder = new AlertDialog.Builder(CollegeActivity.this);
                builder.setMessage("원하시는 작업을 선택해주세요");
                builder.setTitle("정책법학대학")
                        .setCancelable(false)
                        .setPositiveButton("단과대 정보 보기", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://kwabang.website/%ec%a0%95%ec%b1%85%eb%b2%95%ed%95%99%eb%8c%80%ed%95%99/"));
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("커뮤니티", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(getApplicationContext(), LawActivity.class);
                                startActivity(intent);
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("정책법학대학");
                alert.show();
            }
        });

        Button collegeButton7 = (Button) findViewById(R.id.collegebtn7);
        collegeButton7.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                AlertDialog.Builder builder = new AlertDialog.Builder(CollegeActivity.this);
                builder.setMessage("원하시는 작업을 선택해주세요");
                builder.setTitle("경영대학")
                        .setCancelable(false)
                        .setPositiveButton("단과대 정보 보기", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://kwabang.website/%ea%b2%bd%ec%98%81%eb%8c%80%ed%95%99/"));
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("커뮤니티", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                Intent intent = new Intent(getApplicationContext(), BusinessActivity.class);
                                startActivity(intent);
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("경영대학");
                alert.show();
            }
        });

        Button market = (Button) findViewById(R.id.marketbtn);
        market.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://kwabang.website/%ea%b4%91%ec%9a%b4-%eb%a7%88%ec%bc%93/"));
                startActivity(intent);
            }
        });
    }
}